For each of these features the electrodes are along x-axis (column 1 to 8) and the samples are along y-axis (rows)

Note: These features are extracted from the data inside "Raw_data_cropped_and_arranged" folder. That folder contains seperate csv's for all electrodes. In those csv's samples are along y-axis (similar to this), but the points of the wave are along x-axis (columns 1 to 150) because the wave for each sample was taken to be 150 points long.

These features are extracted based on those 150 points for each electrode.