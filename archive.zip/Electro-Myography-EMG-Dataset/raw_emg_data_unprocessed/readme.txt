Hello to the Veteran who decided to work with Raw data

The Electrodes are along the x-axis (columns 1 to 8)
and the data points of the EMG-Wave are alogn the y axis (rows)

Go ahead, crop those signals as you please and extract features you like and
Good Luck :)