The samples are along y axis (rows) and the data points of the EMG-Wave are along x-axis (columns 1 to 150) because the i extracted 150 points for each sample.

Note: The data in this folder is derived from the data inside "Raw_data_unprocessed" folder by applying algorithms to detect abrupt changes in the wave and then crop 150 points if a signal is present.
You are welcome to process data for yourself on your own if this is not satisfying.